package com.mycompany.myapp2;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);  // Menggunakan layout 'main.xml'

        // Menemukan WebView yang ada di layout
        WebView webView = findViewById(R.id.webview);

        // Mengatur WebViewClient untuk membuka halaman web dalam aplikasi
        webView.setWebViewClient(new WebViewClient());

        // Menonaktifkan cache
        WebSettings webSettings = webView.getSettings();
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);  // Menonaktifkan cache
        webSettings.setJavaScriptEnabled(true);  // Mengaktifkan JavaScript
        webSettings.setDomStorageEnabled(true);  // Mengaktifkan penyimpanan DOM

        // Memuat URL ke dalam WebView
        webView.loadUrl("https://mhp3db.github.io/");
    }
}
